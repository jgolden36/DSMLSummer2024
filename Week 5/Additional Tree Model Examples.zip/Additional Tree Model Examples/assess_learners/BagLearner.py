import numpy as np                                                                                                                                           
                                                                                                                                         
                                                                                                                                         
class BagLearner(object):                                                                                                                                        
    """                                                                                                                                          
    This is a Linear Regression Learner. It is implemented correctly.                                                                                                                                        
                                                                                                                                         
    :param verbose: If “verbose” is True, your code can print out information for debugging.                                                                                                                                         
        If verbose = False your code should not generate ANY output. When we test your code, verbose will be False.                                                                                                                                          
    :type verbose: bool                                                                                                                                          
    """                                                                                                                                          
    def __init__(self,learner,kwargs={},bags=10,boost=False,verbose=False):                                                                                                                                        
        """                                                                                                                                          
        Constructor method                                                                                                                                           
        """
        self.learners = []  
        for i in range(0,bags):  
            self.learners.append(learner(**kwargs))  
        self.bags=bags
        self.verbose=verbose                                                                                                                                        
        pass  # move along, these aren't the drones you're looking for                                                                                                                                           
                                                                                                                                         
    def author(self):                                                                                                                                        
        """                                                                                                                                          
        :return: The GT username of the student                                                                                                                                          
        :rtype: str                                                                                                                                          
        """                                                                                                                                          
        return "jgolden36"  # replace tb34 with your Georgia Tech username                                                                                                                                           
                                                                                                                                         
    def add_evidence(self, data_x, data_y):                                                                                                                                          
        for learner in self.learners:
            index = np.random.randint(data_x.shape[0], size=data_y.shape[0])
            learner.add_evidence(data_x[index],data_y[index])
                                                                                                                                         
    def query(self, points):
        predictionPoints=[]
        for learner in self.learners:
            prediction=0
            prediction=prediction+learner.query(points)
            predictionPoints.append(prediction)
        BaggedPred = np.mean(predictionPoints,axis=0)
        return BaggedPred
