import numpy as np
class DTLearner(object):                                                                                                                                         
    """                                                                                                                                          
    This is a Linear Regression Learner. It is implemented correctly.                                                                                                                                        
                                                                                                                                         
    :param verbose: If “verbose” is True, your code can print out information for debugging.                                                                                                                                         
        If verbose = False your code should not generate ANY output. When we test your code, verbose will be False.                                                                                                                                          
    :type verbose: bool                                                                                                                                          
    """                                                                                                                                          
    def __init__(self,leaf_size=1,verbose=False):                                                                                                                                          
        """                                                                                                                                          
        Constructor method                                                                                                                                           
        """      
        self.leaf_size = leaf_size                                                                                                                                    
        pass  # move along, these aren't the drones you're looking for                                                                                                                                           
                                                                                                                                         
    def author(self):                                                                                                                                        
        """                                                                                                                                          
        :return: The GT username of the student                                                                                                                                          
        :rtype: str                                                                                                                                          
        """                                                                                                                                          
        return "jgolden36"  # replace tb34 with your Georgia Tech username                                                                                                                                           
                                                                                                                                         
    def add_evidence(self, data_x, data_y):
        def decision_Tree(data):
            if np.all(data[0,-1]==data[:,-1],axis=0):
                return np.array([["Leaf",np.mean(data[:,-1])]])
            elif data.shape[0]<=self.leaf_size:
                return np.array([["Leaf",np.mean(data[:,-1])]])
            else:
                correlationMatrix=np.corrcoef(data[:,-1],data[:,-1], rowvar=False)  
                maximumCorrelation=np.argmax(np.absolute(correlationMatrix[:-1,-1]))                                                                                                                             
                SplitValue=np.median(data[:,maximumCorrelation])
                SplitRight=data[data[:,maximumCorrelation]>SplitValue]
                SplitLeft=data[data[:,maximumCorrelation]<=SplitValue]
                try:
                    RightTree=decision_Tree(SplitRight)
                except NameError:
                    RightTree=[]
                LeftTree=decision_Tree(SplitLeft)
                root=np.array([[maximumCorrelation, SplitValue]])
                rootWithLeft=np.append(root,LeftTree,axis=0)
                if RightTree!=[]:
                    return np.concatenate(root,LeftTree,RightTree)
                else:
                    return np.array([["Leaf",np.mean(data[:,-1])]])
        ydata=np.array([data_y])
        transposeY=ydata.T
        data=np.append(data_x,transposeY,axis=1)
        self.decisionTreeFitted=decision_Tree(data)   
    def query(self, points):
        import numpy as np
        def QueryPoint(point):
            holder=self.decisionTreeFitted
            while holder[0]!='Leaf':
                BestFeature=holder[0]
                SplitValue=holder[1]
                if point[BestFeature]<=Splitvalue:
                    holder=holder[2]
                else:
                    holder=holder[3]
            return holder[1]
        j=0
        answer=[]
        for row in range(0,points.shape[0]):
            Prediction=float(QueryPoint(points[row,:]))
            answer.append(Prediction)
            predictionAll=np.array(answer)
        return(predictionAll)