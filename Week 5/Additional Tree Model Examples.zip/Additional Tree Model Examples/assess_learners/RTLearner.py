import numpy as np                                                                                                                                           
                                                                                                                                         
                                                                                                                                         
class RTLearner(object):                                                                                                                                         
    """                                                                                                                                          
    This is a Linear Regression Learner. It is implemented correctly.                                                                                                                                        
                                                                                                                                         
    :param verbose: If “verbose” is True, your code can print out information for debugging.                                                                                                                                         
        If verbose = False your code should not generate ANY output. When we test your code, verbose will be False.                                                                                                                                          
    :type verbose: bool                                                                                                                                          
    """                                                                                                                                          
    def __init__(self,leaf_size, verbose=False):                                                                                                                                           
        """                                                                                                                                          
        Constructor method                                                                                                                                           
        """        
        self.leaf_size = leaf_size                                                                                                                                  
        pass  # move along, these aren't the drones you're looking for                                                                                                                                           
                                                                                                                                         
    def author(self):                                                                                                                                        
        """                                                                                                                                          
        :return: The GT username of the student                                                                                                                                          
        :rtype: str                                                                                                                                          
        """                                                                                                                                          
        return "jgolden36"  # replace tb34 with your Georgia Tech username                                                                                                                                           
                                                                                                                                         
    def add_evidence(self, data_x, data_y):                                                                                                                                                                                                                                                                                    
        def decision_Tree(data):
            if np.all(data[0,-1]==data[:,-1],axis=0):
                return np.array([["Leaf",np.mean(data[:,-1])]])
            elif data.shape[0]<=self.leaf_size:
                return np.array([["Leaf",np.mean(data[:,-1])]])
            else:
                maximumCorrelation=np.random.randint(data.shape[1]-3)                                                                                                                       
                SplitValue=np.median(data[:,maximumCorrelation])
                SplitRight=data[data[:,maximumCorrelation]>SplitValue]
                SplitLeft=data[data[:,maximumCorrelation]<=SplitValue]
                try:
                    RightTree=decision_Tree(SplitRight)
                except NameError:
                    RightTree=[]
                LeftTree=decision_Tree(SplitLeft)
                root=np.array([[maximumCorrelation, SplitValue]])
                rootWithLeft=np.append(root,LeftTree,axis=0)
                if RightTree!=[]:
                    return np.concatenate((root,LeftTree,RightTree))
                else:
                    return np.array([["Leaf",np.mean(data[:,-1])]])
        data=np.append(data_x,np.array([data_y]).T,axis=1)
        self.decisionTreeFitted=decision_Tree(data)   
    def query(self, points):
        row=0
        #if not a leaf node
        ans=[]
        row_count=points.shape[0]   #[0] returns rows, [1] returns columns
        for row in range(0,row_count):
            value=self.query_tree(points[row,:])    #pass the current row to query_tree() to determine corresponding value
            ans.append(float(value))
        return ans
    def query_tree(self, my_tuple):
        row=0
        while(self.decisionTreeFitted[row,0]!='Leaf'):
            feature=self.decisionTreeFitted[row,0]
            Split_Val=self.decisionTreeFitted[row,1]
            if my_tuple[int(float(feature))]<=float(Split_Val):
                row=row+int(float(self.decisionTreeFitted[row,2]))    #Left_Tree
            else:
                row=row+int(float(self.decisionTreeFitted[row,3]))    #Right_Tree
        #if a leaf node
        return self.decisionTreeFitted[row,1]